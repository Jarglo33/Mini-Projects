import pygame, random
import utils

class Scene:
	def __init__(self, screen):
		self.screen = screen

class Test_Scene():
	def __init__(self, screen):
		self.screen = screen
		self.current_color=(0,0,0)
		self.prev_color=(0,0,0)
		self.next_color=utils.random_color()
		self.runtime = 0
		self.rt_max = 3
	
	def render(self):
		self.screen.fill(self.current_color)
	
	def update(self, _dt):
		self.runtime += _dt
		if self.runtime >= self.rt_max:
			self.prev_color=self.next_color
			self.next_color=utils.random_color()
			self.runtime = 0
		self.current_color=utils.lerp_color_gamma(self.prev_color,self.next_color, self.runtime%self.rt_max)