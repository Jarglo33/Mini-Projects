import pygame
import scenes

class Game:
	def __init__(self):
		pygame.init()
		self.screen = pygame.display.set_mode((0,0),pygame.FULLSCREEN,pygame.RESIZABLE)
		self.center=self.screen.get_rect().center
		self.clock = pygame.time.Clock()
		self.running = True
		self.scene=scenes.Test_Scene(self.screen)
		self.getTicksLastFrame = 0
	
	def update(self, dt):
		self.scene.update(dt)
	
	def render(self):
		self.screen.fill((0,0,255))
		self.scene.render()
		pygame.display.flip()
	
	def input(self, events):
		for event in events:
			if event.type == pygame.QUIT:
				self.running = False
	
	def run(self):
		while self.running:
			t = pygame.time.get_ticks()
			# deltaTime in seconds.
			deltaTime = (t - self.getTicksLastFrame) / 1000.0
			self.getTicksLastFrame = t
			self.input(pygame.event.get())
			self.update(deltaTime)
			self.render()
		pygame.quit()

if __name__ == '__main__':
	game = Game()
	game.run()