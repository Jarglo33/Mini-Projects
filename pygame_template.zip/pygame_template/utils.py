import pygame, random

def random_color(seed=0):
	random.seed =seed
	col = (
			random.randint(0,255),
			random.randint(0,255),
			random.randint(0,255)
		)
	return col
	
def lerp_color_gamma(a , b, t):
	t = clamp(0,1,t)
	lin_a = [gamma_to_linear(c) for c in a]
	lin_b = [gamma_to_linear(c) for c in b]
	
	r = lin_a[0] + (lin_b[0] - lin_a[0]) * t
	g = lin_a[1] + (lin_b[1] - lin_a[1]) * t
	b = lin_a[2] + (lin_b[2] - lin_a[2]) * t
	
	return (
		linear_to_gamma(r),
		linear_to_gamma(g),
		linear_to_gamma(b)
	)

def gamma_to_linear(c):
	return (c / 255) ** 2.2

def linear_to_gamma(v):
	return int(255 * v ** (1/2.2))

def clamp(_min, _max, value):
	return max(_min, min(_max, value))
	